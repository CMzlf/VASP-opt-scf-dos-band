#!/bin/bash
mkdir optmize
mkdir SC
mkdir DOS
mkdir Band
cp POSCAR ./optmize
cp INCAR_relax ./optmize/INCAR
cp KPOINTS POTCAR ./optmize
cd ./optmize
mpirun -np 12 vasp

cp CONTCAR ../SC/POSCAR
cd ..
cp INCAR_SC ./SC/INCAR
cp KPOINTS POTCAR ./SC
cd ./SC
mpirun -np 12 vasp

cp POSCAR CHGCAR WAVECAR ../DOS
cp POSCAR CHGCAR WAVECAR ../Band
cd ..
cp INCAR_DOS ./DOS/INCAR
cp POTCAR KPOINTS ./DOS
cd ./DOS
mpirun -np 12 vasp

cd ../
cp INCAR_Band ./Band/INCAR
cp POTCAR ./Band
cp KPOINTS_Band ./Band/KPOINTS
cd ./Band
mpirun -np 12 vasp
